#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 23:23:49 2024

@author: sheshta
"""
#Engine DB with RF classifier
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
file_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/Engine Only/EngineFaultDB_Final.csv'  # Update with the actual file path
df = pd.read_csv(file_path)

# Feature engineering: Based on the heatmap, select the features with higher correlation to the target
features_to_use = df.columns[df.corr()['Fault'].abs() > 0.1].tolist()
features_to_use.remove('Fault')  # Remove the target variable from the features list

X = df[features_to_use]
y = df['Fault']

# Data Preprocessing: Scaling the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Handling class imbalance with SMOTE
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X_scaled, y)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_smote, y_smote, test_size=0.2, random_state=42)

# Hyperparameter tuning for RandomForest
param_distributions = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'bootstrap': [True, False]
}

# Model selection and training
rf = RandomForestClassifier(random_state=42)
random_search = RandomizedSearchCV(rf, param_distributions, n_iter=50, cv=5, verbose=2, random_state=42, n_jobs=-1)
random_search.fit(X_train, y_train)

# Best model evaluation
best_rf = random_search.best_estimator_
y_pred = best_rf.predict(X_test)

print(f"Best Parameters: {random_search.best_params_}")
print(f"Test Accuracy: {accuracy_score(y_test, y_pred)}")
print(classification_report(y_test, y_pred))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d')
plt.ylabel('True label')
plt.xlabel('Predicted label')
plt.show()

# Feature Importances
feature_importances = pd.Series(best_rf.feature_importances_, index=features_to_use)
sns.barplot(x=feature_importances, y=feature_importances.index)
plt.xlabel('Feature Importance Score')
plt.ylabel('Features')
plt.title("Visualizing Important Features")
plt.show()
