#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  1 00:33:12 2024

@author: sheshta
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
file_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/Engine Only/EngineFaultDB_Final.csv'  # Make sure to use the correct path for your dataset
df = pd.read_csv(file_path)

# Feature engineering: Based on the heatmap, select the features with higher correlation to the target
features_to_use = df.columns[df.corr()['Fault'].abs() > 0.1].tolist()
features_to_use.remove('Fault')  # Remove the target variable from the features list

X = df[features_to_use]



# Preprocessing steps...
# Feature engineering based on heatmap analysis, etc.

# Encoding categorical variables if necessary
# le = LabelEncoder()
# df['Your_Categorical_Column'] = le.fit_transform(df['Your_Categorical_Column'])

# Feature Scaling
scaler = StandardScaler()
X = scaler.fit_transform(df.drop('Fault', axis=1))  # Assume 'Fault' is the target column
y = df['Fault']

# Handling class imbalance with SMOTE
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X, y)

# Splitting the dataset
X_train, X_test, y_train, y_test = train_test_split(X_smote, y_smote, test_size=0.2, random_state=42)

# Hyperparameter tuning and model training for RandomForest
rf_params = {'n_estimators': [100, 200, 300], 'max_depth': [10, 20, 30, None]}
rf_model = RandomForestClassifier(random_state=42)
rf_random_search = RandomizedSearchCV(rf_model, rf_params, n_iter=10, cv=5, random_state=42)
rf_random_search.fit(X_train, y_train)

# Model evaluation for RandomForest
best_rf = rf_random_search.best_estimator_
rf_y_pred = best_rf.predict(X_test)
rf_accuracy = accuracy_score(y_test, rf_y_pred)

# Hyperparameter tuning and model training for SVM
svm_params = {'C': [0.1, 1, 10], 'kernel': ['rbf', 'linear'], 'gamma': ['scale', 'auto']}
svm_model = SVC(random_state=42, probability=True)
svm_random_search = RandomizedSearchCV(svm_model, svm_params, n_iter=10, cv=5, random_state=42)
svm_random_search.fit(X_train, y_train)

# Model evaluation for SVM
best_svm = svm_random_search.best_estimator_
svm_y_pred = best_svm.predict(X_test)
svm_accuracy = accuracy_score(y_test, svm_y_pred)

# Print results
print(f"RandomForest Best Parameters: {rf_random_search.best_params_}")
print(f"RandomForest Test Accuracy: {rf_accuracy}")
print(classification_report(y_test, rf_y_pred))

print(f"SVM Best Parameters: {svm_random_search.best_params_}")
print(f"SVM Test Accuracy: {svm_accuracy}")
print(classification_report(y_test, svm_y_pred))

# Plot Confusion Matrix for RandomForest
plt.figure(figsize=(10, 7))
sns.heatmap(confusion_matrix(y_test, rf_y_pred), annot=True, fmt='g')
plt.title('RandomForest Confusion Matrix')
plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.show()

# Plot Confusion Matrix for SVM
plt.figure(figsize=(10, 7))
sns.heatmap(confusion_matrix(y_test, svm_y_pred), annot=True, fmt='g')
plt.title('SVM Confusion Matrix')
plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.show()

# Comparing model performance
models = ['RandomForest', 'SVM']
accuracies = [rf_accuracy, svm_accuracy]
plt.bar(models, accuracies, color=['blue', 'green'])
plt.ylabel('Accuracy')
plt.title('Model Comparison')
plt.show()
