import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from imblearn.over_sampling import SMOTE
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/Engine Only/EngineFaultDB_Final.csv'
df = pd.read_csv(file_path)

# If 'Fault' is a categorical variable representing different fault types, let's encode it numerically
if 'Fault' in df.columns:
    df['Fault_Level'] = df['Fault'].astype('category').cat.codes
    y = df['Fault_Level']
    X = df.drop(['Fault', 'Fault_Level'], axis=1)
else:
    y = df['Fault_Level']
    X = df.drop('Fault_Level', axis=1)

# Preprocess the Data: Convert categorical variables to numeric using encoding techniques
le = LabelEncoder()
categorical_features = X.select_dtypes(include=['object']).columns.tolist()
for feature in categorical_features:
    X[feature] = le.fit_transform(X[feature])

# Split the Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the Data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Addressing Imbalance with SMOTE
smote = SMOTE(random_state=42)
X_train_smote, y_train_smote = smote.fit_resample(X_train_scaled, y_train)

# Define and train the RandomForestRegressor
model = RandomForestRegressor(random_state=42)
model.fit(X_train_smote, y_train_smote)

# Evaluate the model
y_pred = model.predict(X_test_scaled)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Print performance metrics
print(f"Test MSE: {mse}")
print(f"Test R2 Score: {r2}")

# Feature Importances Visualization
feature_importances = pd.Series(model.feature_importances_, index=X.columns)
plt.figure(figsize=(10, 8))
sns.barplot(x=feature_importances, y=feature_importances.index)
plt.title('Feature Importance')
plt.show()
