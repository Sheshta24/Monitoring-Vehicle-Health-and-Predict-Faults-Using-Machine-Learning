

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical
import seaborn as sns
import matplotlib.pyplot as plt

def load_and_preprocess_data(filepath, correlation_threshold=0.1):
    df = pd.read_csv(filepath)
    corr_matrix = df.corr()
    high_corr_features = corr_matrix.index[corr_matrix['Fault'].abs() > correlation_threshold].tolist()
    high_corr_features.remove('Fault')
    X = df[high_corr_features]
    y = df['Fault']
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    smote = SMOTE(random_state=42)
    X_smote, y_smote = smote.fit_resample(X_scaled, y)
    return X_smote, y_smote

def split_data(X, y, for_nn=False):
    if not for_nn:
        return train_test_split(X, y, test_size=0.2, random_state=42)
    else:
        y_encoded = to_categorical(y)
        return train_test_split(X, y_encoded, test_size=0.2, random_state=42)

def train_ml_model(model, params, X_train, y_train):
    random_search = RandomizedSearchCV(model, params, n_iter=10, cv=5, random_state=42)
    random_search.fit(X_train, y_train)
    return random_search.best_estimator_

def evaluate_model(model, X_test, y_test, model_name, for_nn=False):
    if not for_nn:
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
    else:
        _, accuracy = model.evaluate(X_test, y_test, verbose=0)
        y_pred = model.predict(X_test)
        y_pred_classes = np.argmax(y_pred, axis=1)
        y_test_classes = np.argmax(y_test, axis=1)
        print(classification_report(y_test_classes, y_pred_classes))
    
    print(f"{model_name} Test Accuracy: {accuracy}")
    return accuracy, y_pred

def plot_confusion_matrix(y_test, y_pred, title):
    if len(y_pred.shape) > 1:  # For neural network predictions
        y_pred = np.argmax(y_pred, axis=1)
        y_test = np.argmax(y_test, axis=1)
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(10, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title(title)
    plt.ylabel('Actual Label')
    plt.xlabel('Predicted Label')
    plt.show()

def create_neural_network(input_dim, output_dim):
    model = Sequential()
    model.add(Dense(64, input_dim=input_dim, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(32, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(output_dim, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

def plot_training_history(history):
    plt.figure(figsize=(12, 6))

    # Plot training & validation accuracy values
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Train')
    plt.plot(history.history['val_accuracy'], label='Validation')
    plt.title('Model Accuracy')
    plt.ylabel('Accuracy')
    plt.xlabel('Epoch')
    plt.legend()

    # Plot training & validation loss values
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Train')
    plt.plot(history.history['val_loss'], label='Validation')
    plt.title('Model Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend()

    plt.tight_layout()
    plt.show()

def main():
    file_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/Engine Only/EngineFaultDB_Final.csv' # Update this path
    X_smote, y_smote = load_and_preprocess_data(file_path, correlation_threshold=0.1)
    
    # Train and evaluate ML models
    X_train, X_test, y_train, y_test = split_data(X_smote, y_smote)
    models = {
        'RandomForest': (RandomForestClassifier(random_state=42), {'n_estimators': [100, 200, 300], 'max_depth': [10, 20, 30, None]}),
        'SVM': (SVC(random_state=42, probability=True), {'C': [0.1, 1, 10], 'kernel': ['rbf', 'linear'], 'gamma': ['scale', 'auto']}),
        'KNN': (KNeighborsClassifier(), {'n_neighbors': [3, 5, 7, 9], 'metric': ['euclidean', 'manhattan']})
    }
    
    accuracies = {}
    for model_name, (model, params) in models.items():
        best_model = train_ml_model(model, params, X_train, y_train)
        accuracy, y_pred = evaluate_model(best_model, X_test, y_test, model_name)
        plot_confusion_matrix(y_test, y_pred, f"{model_name} Confusion Matrix")
        accuracies[model_name] = accuracy
    
    # Train and evaluate Neural Network
    X_train_nn, X_test_nn, y_train_nn, y_test_nn = split_data(X_smote, y_smote, for_nn=True)
    nn_model = create_neural_network(X_train_nn.shape[1], y_train_nn.shape[1])
    history = nn_model.fit(X_train_nn, y_train_nn, validation_split=0.1, epochs=100, batch_size=32, verbose=1)
    nn_accuracy, y_pred_nn = evaluate_model(nn_model, X_test_nn, y_test_nn, "Neural Network", for_nn=True)
    plot_confusion_matrix(y_test_nn, y_pred_nn, "Neural Network Confusion Matrix")
    accuracies['Neural Network'] = nn_accuracy

    # Plot training history for Neural Network
    plot_training_history(history)

    # Plot comparison
    plt.figure(figsize=(10, 7))
    plt.bar(accuracies.keys(), accuracies.values(), color=['blue', 'green', 'red', 'purple'])
    plt.ylabel('Accuracy')
    plt.title('Model Comparison')
    plt.show()

if __name__ == "__main__":
    main()
