import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from imblearn.over_sampling import SMOTE
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/vehicle_health.csv')  # Make sure the path is correct

# Preprocessing the data
# Encode categorical variables
le = LabelEncoder()
df['Air_filter_status'] = le.fit_transform(df['Air_filter_status'])
df['Transmission_Fluid_Level'] = le.fit_transform(df['Transmission_Fluid_Level'])
df['Coolant_Level'] = le.fit_transform(df['Coolant_Level'])
df['Engine_Oil_Level'] = le.fit_transform(df['Engine_Oil_Level'])

# Encoding the target variable 'Target_Condition'
target = le.fit_transform(df['Target_Condition'])
df.drop(['Target_Condition'], axis=1, inplace=True)

# Define features
X = df.values

# Handling class imbalance with SMOTE
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X, target)

# Convert the target variable to categorical
y_smote_categorical = to_categorical(y_smote)

# Standardizing the features with StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_smote)

# Splitting the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_smote_categorical, test_size=0.2, random_state=42)

# Deep Learning Model: Multilayer Perceptron (MLP)
model = Sequential()
model.add(Dense(64, input_dim=X_train.shape[1], activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(32, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(y_train.shape[1], activation='softmax'))  # Output layer with 'softmax' for multiclass classification

# Compile the model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Model Summary
model.summary()

# Train the model
history = model.fit(X_train, y_train, validation_split=0.1, epochs=100, batch_size=32, verbose=1)

# Evaluate the model
_, accuracy = model.evaluate(X_test, y_test, verbose=0)
print(f'Test Accuracy: {accuracy:.4f}')

# Plot the training history
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Accuracy over epochs')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Loss over epochs')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend()
plt.tight_layout()
plt.show()

# Optionally, save your model
# model.save('vehicle_health_model.h5')
