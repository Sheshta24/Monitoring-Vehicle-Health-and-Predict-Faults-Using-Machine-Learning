#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 22:54:36 2024

@author: sheshta
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from imblearn.over_sampling import SMOTE
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/vehicle_health.csv')  # Update the path to your file location

# Preprocessing the data
# Encode categorical variables using LabelEncoder
le = LabelEncoder()
categorical_features = ['Air_filter_status', 'Transmission_Fluid_Level', 'Coolant_Level', 'Engine_Oil_Level', 'Target_Condition']
for feature in categorical_features:
    df[feature] = le.fit_transform(df[feature])

# Define features and target variable
X = df.drop('Target_Condition', axis=1)
y = df['Target_Condition']

# Handling class imbalance with SMOTE
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X, y)

# Standardizing the features with StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_smote)

# Splitting the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_smote, test_size=0.2, random_state=42)

# Model Selection: RandomForestClassifier
# Setup the hyperparameter grid for tuning
param_grid = {
    'n_estimators': [50, 100, 150],
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10]
}

# Instantiate RandomForestClassifier
rf_clf = RandomForestClassifier(random_state=42)

# Instantiate GridSearchCV
grid_search = GridSearchCV(rf_clf, param_grid, cv=5, scoring='accuracy', n_jobs=-1)

# Fit grid_search to the data
grid_search.fit(X_train, y_train)

# Extracting the best parameters and best model
best_params = grid_search.best_params_
best_model = grid_search.best_estimator_

# Predictions with the best model
y_pred = best_model.predict(X_test)

# Model Evaluation
accuracy = accuracy_score(y_test, y_pred)
class_report = classification_report(y_test, y_pred)

# Feature Importance Visualization
feature_importances = best_model.feature_importances_
indices = np.argsort(feature_importances)[::-1]

# Plotting Feature Importances
plt.figure(figsize=(12, 8))
plt.title("Feature importances")
plt.bar(range(X_train.shape[1]), feature_importances[indices], color="r", align="center")
plt.xticks(range(X_train.shape[1]), [X.columns[i] for i in indices], rotation=90)
plt.xlim([-1, X_train.shape[1]])
plt.tight_layout()  # Adjust the plot to ensure everything fits without overlapping
plt.show()

# Output the model evaluation metrics
print(f"Best Parameters: {best_params}")
print(f"Accuracy: {accuracy}")
print("Classification Report:")
print(class_report)
