#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 13:40:05 2024

@author: sheshta
"""

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
data_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/EngineFaultDB_Final.csv'
df = pd.read_csv(data_path)

# Prepare matplotlib figure
fig = plt.figure(figsize=(15, 20))

# List of column names to create box plots for, excluding 'Fault'
columns_to_plot = ['MAP', 'TPS', 'Force', 'Power', 'RPM', 'Consumption L/H',
                   'Consumption L/100KM', 'Speed', 'CO', 'HC', 'CO2', 'O2', 'Lambda', 'AFR']

# Create box plots for each column
for i, column in enumerate(columns_to_plot, start=1):
    ax = fig.add_subplot(5, 3, i)  # Create subplot for each variable
    sns.boxplot(x='Fault', y=column, data=df, palette="Set3")
    ax.set_title(column)
    ax.set_xlabel('')
    ax.set_ylabel('')

# Tight layout to prevent overlapping
plt.tight_layout()

# Save the complete figure with all box plots
heatmap_file_path_full = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/boxplot.png'
plt.savefig(heatmap_file_path_full)
# Show the figure
plt.show()

# Path to the saved figure
'/mnt/data/all_box_plots.png'
