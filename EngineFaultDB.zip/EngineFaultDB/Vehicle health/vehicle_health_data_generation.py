#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 17:14:54 2024

@author: sheshta
"""

from faker import Faker
import numpy as np
import pandas as pd

# Initialize Faker
fake = Faker()

# Define the number of records
num_records = 70000

# Define lists for categorical data choices
air_filter_status_choices = ['Clean', 'Dirty']
transmission_fluid_level_choices = ['Good', 'Low']
coolant_level_choices = ['Normal', 'Low']
engine_oil_level_choices = ['Optimal', 'Low']
target_condition_choices = ['Excellent', 'Good', 'Needs Serviced', 'Very Bad Condition']

# Generate the synthetic dataset
synthetic_data = {
    'Engine_temperature': np.random.uniform(20, 150, num_records).round(2),
    'Oil_Pressure': np.random.uniform(1, 10, num_records).round(2),
    'Battery_Voltage': np.random.uniform(11, 15, num_records).round(2),
    'Fuel_Level': np.random.uniform(0, 100, num_records).round(2),
    'Mileage': np.random.randint(0, 200001, num_records),
    'Tire_Pressure': np.random.uniform(20, 40, num_records).round(2),
    'Brake_Fluid_Level': np.random.uniform(0.1, 1, num_records).round(2),
    'Air_filter_status': np.random.choice(air_filter_status_choices, num_records),
    'Transmission_Fluid_Level': np.random.choice(transmission_fluid_level_choices, num_records),
    'Coolant_Level': np.random.choice(coolant_level_choices, num_records),
    'Engine_Oil_Level': np.random.choice(engine_oil_level_choices, num_records),
    'Target_Condition': np.random.choice(target_condition_choices, num_records)
}

# Create a DataFrame
vehicle_health_df = pd.DataFrame(synthetic_data)

# Save the DataFrame to a CSV file
vehicle_health_df.to_csv('/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/vehicle_health.csv', index=False)

# Display the first few entries of the dataset
vehicle_health_df.head()
