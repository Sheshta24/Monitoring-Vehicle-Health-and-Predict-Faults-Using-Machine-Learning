#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 17:46:47 2024

@author: sheshta
"""

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
# Load the dataset from the provided CSV file path
data_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/vehicle_health.csv' # Update this path to your dataset's location
df = pd.read_csv(data_path)

# Convert categorical columns to category type and then use their codes for correlation analysis
non_numeric_columns = ['Air_filter_status', 'Transmission_Fluid_Level', 
                       'Coolant_Level', 'Engine_Oil_Level', 'Target_Condition']
for col in non_numeric_columns:
    df[col] = df[col].astype('category').cat.codes

# Calculate the correlation matrix with only numeric data
correlation_matrix = df.corr()

# Set up the matplotlib figure for the heatmap
fig_heatmap, ax_heatmap = plt.subplots(figsize=(11, 9))
colormap = sns.diverging_palette(230, 20, as_cmap=True)
sns.heatmap(correlation_matrix, annot=True, fmt=".2f", cmap=colormap, vmax=1, vmin=-1,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
plt.tight_layout()
plt.show()  # Display the heatmap

# Set up the matplotlib figure for the box plots
fig_boxplot, axes_boxplot = plt.subplots(3, 3, figsize=(15, 20))  # Adjust for the correct layout
axes_boxplot = axes_boxplot.flatten()  # Flatten the axes array for easy iteration

# List of numeric columns to create box plots for
numeric_columns = ['Engine_temperature', 'Oil_Pressure', 'Battery_Voltage',
                   'Fuel_Level', 'Mileage', 'Tire_Pressure', 'Brake_Fluid_Level']

# Create box plots for each numeric column
for i, column in enumerate(numeric_columns):
    sns.boxplot(x='Target_Condition', y=column, data=df, palette="Set3", ax=axes_boxplot[i])
    axes_boxplot[i].set_title(column)
    axes_boxplot[i].set_xlabel('')
    axes_boxplot[i].set_ylabel('')

# Remove any unused subplots
for j in range(i + 1, len(axes_boxplot)):
    fig_boxplot.delaxes(axes_boxplot[j])

plt.tight_layout()
plt.show()  # Display the box plots

#comparison brake fluid levels across target conditions
#data_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/vehicle_health.csv' # Update this path to your dataset's location
df = pd.read_csv(data_path)  # Make sure to update the path to your CSV file

# Check for unique values in the 'Target_Condition' and sort them for the plot
order = ['Needs Serviced', 'Good', 'Excellent', 'Very Bad Condition']

# Create the box plot
plt.figure(figsize=(10, 8))
sns.boxplot(data=df, x='Target_Condition', y='Brake_Fluid_Level', order=order)
plt.title('Comparison of Brake Fluid Levels across Target Conditions')
plt.ylabel('Brake Fluid Level')
plt.xlabel('Target Condition')

# Show the plot
plt.show()

# Load the dataset
df = pd.read_csv(data_path)

# The provided image is a count plot for the 'Air_filter_status' across 'Target_Condition'
plt.figure(figsize=(10, 8))
count_plot = sns.countplot(x='Target_Condition', hue='Air_filter_status', data=df,
                           palette='viridis', order=['Needs Serviced', 'Good', 'Excellent', 'Very Bad Condition'])

plt.title('Relationship between Air Filter Status and Target Condition')
plt.xlabel('Target Condition')
plt.ylabel('Count')
plt.legend(title='Air Filter Status')

# Show the plot
plt.show()




