#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 13:13:15 2024

@author: sheshta
"""

# Full program to generate the heatmap with annotated correlation values for all cells

# Importing required libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset from the provided CSV file path
data_path = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/EngineFaultDB_Final.csv'
df = pd.read_csv(data_path)

# Calculate the correlation matrix
correlation_matrix = df.corr()

# Set up the matplotlib figure with a specified figure size
fig, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
colormap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with annotations for each cell, with no mask applied
sns.heatmap(correlation_matrix, annot=True, fmt=".2f", cmap=colormap, vmax=1, vmin=-1,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})

# Improve the layout to prevent cutting off edges on save
plt.tight_layout()

# Save the heatmap to a file
heatmap_file_path_full = '/Users/sheshta/Library/Mobile Documents/com~apple~CloudDocs/Term 2 MSc/AI for Eng Design/Project 2/EngineFaultDB/heatmap.png'
plt.savefig(heatmap_file_path_full)

# Show the plot
plt.show()

# Provide the path to the saved heatmap
heatmap_file_path_full






